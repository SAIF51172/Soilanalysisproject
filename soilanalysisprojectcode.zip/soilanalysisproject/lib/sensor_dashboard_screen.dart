import 'package:flutter/material.dart';
import 'package:flip_card/flip_card.dart';
import 'prediction_screen.dart';

class SensorDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const customGreen = Color(0xFF54744F);
    return Scaffold(
      appBar: AppBar(
        title: Text('Sensor Dashboard'),
        backgroundColor: customGreen,
        actions: [
          IconButton(
            icon: Icon(Icons.arrow_forward),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PredictionScreen()),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          color: customGreen,
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  color: customGreen,
                ),
                child: Image.asset(
                  'assets/images/Logo1.png',
                  fit: BoxFit.fitHeight,
                ),
              ),
              Divider(height: 30.0, color: Colors.white10),
              ListTile(
                onTap: () {
                  Navigator.pop(context); // Close the drawer
                  _logout(context); // Call logout function
                },
                leading: Icon(Icons.logout, size: 30, color: Colors.black),
                title: Text('Logout', style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold)),
              ),
              Divider(height: 10.0, color: Colors.white10),
              // Add more drawer items as needed
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          Opacity(
            opacity: 0.5,
            child: Image.asset(
              'assets/images/Background.jpeg',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: GridView.count(
              crossAxisCount: 2,
              children: [
                _buildGridTile(context, 'assets/images/tempreture.jpg', 'Temp Lvl', 'Value of Temperature'),
                _buildGridTile(context, 'assets/images/Moisture.jpg', 'Moisture Lvl', 'Value of Moisture'),
                _buildGridTile(context, 'assets/images/WaterLevel.png', 'Water Lvl', 'Value of Water Level'),
                _buildGridTile(context, 'assets/images/Humidity.jpg', 'Humidity Lvl', 'Value of Humidity'),
                _buildGridTile(context, 'assets/images/nitrogen.jpg', 'Nitrogen Lvl', 'Value of Nitrogen'),
                _buildGridTile(context, 'assets/images/phosphorus.png', 'Phosphorus Lvl', 'Value of Phosphorus'),
                _buildGridTile(context, 'assets/images/potassium.png', 'Potassium Lvl', 'Value of Potassium'),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: customGreen,
        child: Container(height: 50.0),
      ),
    );
  }

  Widget _buildGridTile(BuildContext context, String imagePath, String label, String value) {
    return GestureDetector(
      onTap: () {
        // Add navigation or any action here if needed
      },
      child: FlipCard(
        direction: FlipDirection.HORIZONTAL,
        front: _buildGridTileFront(imagePath, label),
        back: _buildGridTileBack(value),
      ),
    );
  }

  Widget _buildGridTileFront(String imagePath, String label) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          imagePath,
          height: 80,
          width: 80,
        ),
        SizedBox(height: 10),
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ],
    );
  }

  Widget _buildGridTileBack(String value) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF54744F),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            spreadRadius: 2,
          ),
        ],
      ),
      margin: EdgeInsets.all(8),
      padding: EdgeInsets.all(16),
      child: Center(
        child: Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
    );
  }

  void _logout(BuildContext context) {
    // Perform logout operations here (e.g., clear user data, etc.)

    // Show a SnackBar to notify the user of a successful logout
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Successfully logged out'),
        duration: Duration(seconds: 2),
      ),
    );

    // Navigate to the login screen
    Navigator.pushReplacementNamed(context, '/login');
  }
}
