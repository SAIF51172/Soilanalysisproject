import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const customGreen = Color(0xFF54744F);
    return Scaffold(
      appBar: AppBar(
        title: Text('About Us'),
        backgroundColor: customGreen,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/Background.jpeg'), // Ensure you have the image in the correct path
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            color: Colors.black.withOpacity(0.4), // Optional overlay for better text contrast
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'About Our Application',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Make text color white for better visibility
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  'Welcome to our Smart Agriculture Dashboard! We are dedicated to revolutionizing the way farmers and agricultural enthusiasts monitor and manage their crops. '
                      'Our application provides real-time insights and predictions based on data collected from various sensors deployed in the field.'
                      'By tracking critical parameters such as temperature, moisture level, water level, humidity, and nutrient levels (nitrogen, phosphorus, and potassium), '
                      'we empower users to make informed decisions for optimal crop health and yield.'
                      'Our user-friendly interface includes features like flip cards for quick data visualization and an intuitive dashboard for comprehensive analysis. '
                      'With our commitment to leveraging cutting-edge technology, we aim to enhance agricultural productivity, sustainability, and efficiency. '
                      'Join us on this journey to smarter farming and a greener future!',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white70, // Slightly lighter text for paragraphs
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  'Our application offers:',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  '- User-friendly interface\n- Real-time updates\n- Secure and reliable\n- Customizable settings\n- 24/7 customer support',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
