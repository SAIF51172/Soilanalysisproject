import 'package:flutter/material.dart';
import 'package:flip_card/flip_card.dart';

class PredictionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const customGreen = Color(0xFF54744F);
    return Scaffold(
      appBar: AppBar(
        title: Text('Prediction Screen'),
        backgroundColor: customGreen,
      ),
      body: Stack(
        children: [
          Opacity(
            opacity: 0.5,
            child: Image.asset(
              'assets/images/Background.jpeg', // Your background image path
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Logo at the top left corner
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Image.asset(
                      'assets/images/Logo1.png', // Your logo image path
                      height: 80,
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildGridTile(context, 'assets/images/tempreture.jpg', 'Temp Lvl', 'Value of Temperature'),
                      _buildGridTile(context, 'assets/images/Moisture.jpg', 'Moisture Lvl', 'Value of Moisture'),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildGridTile(context, 'assets/images/WaterLevel.png', 'Water Lvl', 'Value of Water Level'),
                      _buildGridTile(context, 'assets/images/Humidity.jpg', 'Humidity Lvl', 'Value of Humidity'),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildGridTile(context, 'assets/images/nitrogen.jpg', 'Nitrogen Lvl', 'Value of Nitrogen'),
                      _buildGridTile(context, 'assets/images/phosphorus.png', 'Phosphorus Lvl', 'Value of Phosphorus'),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildGridTile(context, 'assets/images/potassium.png', 'Potassium Lvl', 'Value of Potassium'),
                    ],
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 100,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(
                        'Predictions',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: customGreen,
        child: Container(height: 50.0),
      ),
    );
  }

  Widget _buildGridTile(BuildContext context, String imagePath, String label, String value) {
    return GestureDetector(
      onTap: () {
        // Add navigation or any action here if needed
      },
      child: FlipCard(
        direction: FlipDirection.HORIZONTAL,
        front: _buildGridTileFront(imagePath, label),
        back: _buildGridTileBack(value),
      ),
    );
  }

  Widget _buildGridTileFront(String imagePath, String label) {
    return Container(
      width: 150,
      height: 150,
      margin: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            imagePath,
            height: 80,
            width: 80,
          ),
          SizedBox(height: 10),
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGridTileBack(String value) {
    return Container(
      width: 150,
      height: 150,
      margin: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}
