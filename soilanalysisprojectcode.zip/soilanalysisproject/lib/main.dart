import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'login.dart';
import 'SignupScreen.dart';
import 'ForgetPasswordScreen.dart';
import 'about_us_screen.dart';
import 'prediction_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
        apiKey: "AIzaSyAZMdiw2ez6ibLmwUvGgilNH09-0Lj9wx0",
        appId: "1:518613372775:android:68fad130c22380c2e129c2",
        messagingSenderId: "518613372775",
        projectId: "soil-analysis-crop-fertility-p"
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AgroSense',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      initialRoute: '/',
      routes: {
        '/login': (context) => LoginScreen(),
        '/sign-up': (context) => SignUpScreen(),
        '/forget-password': (context) => ForgetPasswordScreen(),
        '/About': (context) => AboutScreen(),
      },
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  //final CollectionReference_SoilAnalysis= FirebaseFirestore.instance.collection('Soil Analysis');
  late AnimationController _controller;
  late Animation<double> _fadeInAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    );

    _fadeInAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const customGreen = Color(0xFF54744F);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customGreen,
      ),
      drawer: Drawer(
        child: Container(
          color: customGreen,
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  color: customGreen,
                ),
                child:
                Image.asset(
                  'assets/images/Logo1.png',
                  fit: BoxFit.fitHeight,
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/login');
                },
                leading: Icon(Icons.login, size: 30, color: Colors.black),
                title: Text('Login', style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold)),
              ),
              Divider(height: 10.0, color: Colors.white10),
              ListTile(
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/About');
                },
                leading: Icon(Icons.info, size: 30, color: Colors.black),
                title: Text('About Us', style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold)),
              ),
              Divider(height: 10.0, color: Colors.white10),
              // Add more drawer items as needed
            ],
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image with reduced opacity
          Opacity(
            opacity: 0.5,
            child: Image.asset(
              'assets/images/Background.jpeg',
              fit: BoxFit.cover,
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeInAnimation,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/images/Logo1.png',
                    height: 165,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'AgroSense',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: customGreen,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Your Smart Farming Companion',
                    style: TextStyle(
                      fontSize: 22,
                      color: customGreen,
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(5, (index) => DotIndicator(isActive: index == 2)),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      // Navigate to LoginScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: customGreen,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 60, vertical: 10),
                    ),
                    child: Text(
                      'Get Started',
                      style: TextStyle(
                        fontSize: 22,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DotIndicator extends StatelessWidget {
  final bool isActive;

  DotIndicator({required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.0),
      height: isActive ? 10.0 : 8.0,
      width: isActive ? 10.0 : 8.0,
      decoration: BoxDecoration(
        color: isActive ? Color(0xFF54744F) : Colors.grey,
        borderRadius: BorderRadius.circular(6.0),
      ),
    );
  }
}
